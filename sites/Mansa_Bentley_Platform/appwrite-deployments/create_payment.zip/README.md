# create_payment

Appwrite Function for BentleyBot

## Deployment

1. Upload this ZIP to Appwrite Cloud Console
2. Select Runtime: Node.js 18.0 or later
3. Set Entry Point: index.js
4. Add environment variables:
   - APPWRITE_FUNCTION_ENDPOINT
   - APPWRITE_FUNCTION_PROJECT_ID
   - APPWRITE_API_KEY
   - APPWRITE_DATABASE_ID
5. Deploy and test

## Function ID

After deployment, copy the Function ID and add to your .env file:
```env
APPWRITE_FUNCTION_ID_CREATE_PAYMENT=your_function_id_here
```
