const { createClient } = require('./_shared/appwriteClient');
module.exports = async (req, res) => {
    return res.json({ message: 'Shared module loaded successfully!', hasCreateClient: typeof createClient === 'function' });
};
